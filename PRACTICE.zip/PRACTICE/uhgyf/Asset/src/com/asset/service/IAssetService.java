package com.asset.service;

import java.util.List;

import com.asset.dtobean.AssetDtoBean;
import com.asset.exception.AssetException;

public interface IAssetService {
	public abstract int assetServiceInsertion(AssetDtoBean object) throws AssetException;
	public abstract List<AssetDtoBean> assetServiceRetrive() throws AssetException;
	public abstract List<AssetDtoBean> assetServiceRetriveById(String assetId) throws AssetException;

}
