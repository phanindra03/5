package com.ra.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ra.dao.IRechargeDao;
import com.ra.dao.RechargeDaoImpl;
import com.ra.dtobean.RechargeBean;
import com.ra.exception.RechargeException;

public class RechargeServiceImpl implements IRechargeService{
	
	static IRechargeDao recDao=null;
	
	
	
	
	
	@Override
	public int rechargeServ(RechargeBean rec) throws RechargeException {
		
		recDao=new RechargeDaoImpl();
		int result1=recDao.rechargeDao(rec);	
		return result1;
	}


	@Override
	public List<RechargeBean> rechargeServiceImpl() throws RechargeException {
	
		recDao=new RechargeDaoImpl();
		return recDao.rechargeHistoryDao();
	}




	@Override
	public boolean validateName(String name) {
		Pattern pattern=Pattern.compile("[A-Z][a-zA-Z]{6}");
		Matcher m=pattern.matcher(name);
		if(m.matches())	{
			return true;
		}
		else 
		{
			return false;		 
		}
		
	}


	@Override
	public boolean validateName() {
		// TODO Auto-generated method stub
		return false;
	}


	














	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
