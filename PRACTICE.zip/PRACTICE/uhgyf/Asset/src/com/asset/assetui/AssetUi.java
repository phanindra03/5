package com.asset.assetui;


import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.asset.dtobean.AssetDtoBean;
import com.asset.exception.AssetException;
import com.asset.service.AssetService;
import com.asset.service.IAssetService;

public class AssetUi {
	static Scanner sc=null;
	static IAssetService assetService=null;
	
	
    static Logger logger = Logger.getRootLogger();
	
	public static void main(String[] args) {
		
		PropertyConfigurator.configure("resources/log4j.properties");
		
		System.out.println("choose the below option");
		System.out.println("1 --->  insert asset data");
		System.out.println("2 --->  retrive all asset data");
		System.out.println("3 --->  retrive asset data by Id");
		sc=new Scanner(System.in);
		int option=sc.nextInt();
		switch (option) {
		
		
		case 1:
			logger.info("OPTION 1 SELECTED");
			System.out.println("ENTER YOUR EMPLOYEE ID");
			String empId;
			do {
			empId=sc.next();
			}while(AssetService.validateempId(empId)==false);
			
			System.out.println("ENTER YOUR EMPLOYEE NAME");
			String empName;
			do {
			empName=sc.next();
			}while(AssetService.validateempName(empName)==0);
			
			System.out.println("ENTER YOUR MOBILE NUMBER");
			String mobileNum;
			do {
			mobileNum=sc.next();
			}while(AssetService.validatemobileNumber(mobileNum)==0);
			
		/*	System.out.println("ENTER THE DATE");
			String allocateDate;
			do {
			allocateDate=sc.next();
			}while(AssetService.validateallocateDate(allocateDate)==0);*/
			
			AssetDtoBean asset=new AssetDtoBean(empId,empName,mobileNum);
			int status=0;
			
			try {
			status=assetUiInsertion(asset);
			}catch(AssetException e) {
				logger.warn("DATA NOT INSERTED");
				System.out.println("data is not inserted");
			}
			
			if(status>0) {
				logger.info("DATA INSERTED SUCESSFULLY");
				System.out.println(status+"data is inserted");
			}
			break;
        
		
		case 2:
			List<AssetDtoBean> assetretrivelist=null;
			
			try {
			assetretrivelist= assetUiRetrive();
			}catch(AssetException e) {
				logger.warn("DATA NOT RETRIVED");
				System.out.println("problem in retriving data");
			}
			
			for(AssetDtoBean s:assetretrivelist) {
				logger.info("DATA RETRIVED SUCESSFULLY");
				System.out.println(s);
			}
			
			
			break;
        
		case 3:
        	List<AssetDtoBean> assetretrivebyidlist=null;
        	System.out.println("ENTER THE ASSET ID");
        	String assetId=sc.next();
        	try {
        	assetretrivebyidlist= assetUiRetriveById(assetId);
        	}catch(AssetException e) {
        		logger.warn("DATA NOT RETRIVED");
        		System.out.println("problem in retriving data");
        	}
        	for(AssetDtoBean s:assetretrivebyidlist) {
        		logger.info("DATA RETRIVED SUCESSFULLY");
        		System.out.println(s);
        	}
	
	        break;

		default:
			System.exit(0);
			break;
		}
	}
	
	public static int assetUiInsertion(AssetDtoBean object) throws AssetException{
		assetService=new AssetService();	
        int status = assetService.assetServiceInsertion(object);
		return status;
	}
	public static List<AssetDtoBean> assetUiRetrive() throws AssetException{
		assetService=new AssetService();
		return assetService.assetServiceRetrive();
	}
	public static List<AssetDtoBean> assetUiRetriveById(String assetId) throws AssetException{
		assetService=new AssetService();
		return assetService.assetServiceRetriveById(assetId);
	}	

}
