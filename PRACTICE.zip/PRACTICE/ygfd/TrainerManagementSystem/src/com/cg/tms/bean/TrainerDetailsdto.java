package com.cg.tms.bean;

public class TrainerDetailsdto {
	
	static long id; 
	public static long getId() {
		return id;
	}
	public static void setId(long id) {
		TrainerDetailsdto.id = id;
	}
	public static String getTname() {
		return tname;
	}
	public static void setTname(String tname) {
		TrainerDetailsdto.tname = tname;
	}
	public static String getLocation() {
		return location;
	}
	public static void setLocation(String location) {
		TrainerDetailsdto.location = location;
	}
	public static String getDesignation() {
		return designation;
	}
	public static void setDesignation(String designation) {
		TrainerDetailsdto.designation = designation;
	}
	public static String getPhn() {
		return phn;
	}
	public static void setPhn(String phn) {
		TrainerDetailsdto.phn = phn;
	}
	public static String getTechnology() {
		return technology;
	}
	public static void setTechnology(String technology) {
		TrainerDetailsdto.technology = technology;
	}
	static String tname;
	static String location;
	static String designation;
	static String technology;
	static String phn;

}
