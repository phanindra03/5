package com.capgemini.doctors.exception;

public class DoctorsException extends Exception {

	private static final long serialVersionUID = 4400430322900774199L;
	
	public DoctorsException(){
		super();
	}
	public DoctorsException(String msg) {
		super(msg);
	}
}
