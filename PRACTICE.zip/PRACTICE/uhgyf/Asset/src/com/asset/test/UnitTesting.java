package com.asset.test;

import java.sql.Connection;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.asset.dao.AssetDao;
import com.asset.dao.IAssetDao;
import com.asset.dbutil.DbUtil;
import com.asset.dtobean.AssetDtoBean;
import com.asset.exception.AssetException;

import junit.framework.Assert;

public class UnitTesting {
	static Connection status=null;
    static AssetDtoBean asset =null;
    static AssetDao dao=null;
    int res=0;
    
    @BeforeClass
    public static void start() {
           status=null;
    }
    
    @Before
    public void init() {
         System.out.println("starting db connection");
    }
    
    
    @Test
    public void dbConnection() {
          DbUtil util=new DbUtil();
          Connection status=util.getConnect();
          Assert.assertNotNull(status);
    }
    
    @After
    public void end() {
           System.out.println("ending the db connection ");
    }

    @Before
    public void init1() throws AssetException {
        dao=new AssetDao();
        asset=new AssetDtoBean("EMP756","PHANINDRA","9874563214","12/12/2018",45687,1);
    
    }

    @Test
    public void storeDetail() throws AssetException {
        res=dao.storeDetails(asset);
        Assert.assertEquals(2050, res);
    }


    @Test
    public void retrivedetails() throws AssetException {
        IAssetDao dao1=new AssetDao();
        List<AssetDtoBean> lis = null;
        lis = dao1.getAllRecharges();
        Assert.assertNotNull(lis);
    
     }
     @Test
     public void retrivedetails1() throws AssetException {
           IAssetDao dao1=new AssetDao();
           List<AssetDtoBean> lis = null;
           lis = dao1.getAllRecharges();
           Assert.assertNull(lis);
     }

}
