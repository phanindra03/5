package com.cg.tms.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.tms.Exceptions.TrainerException;

public class DBConnection {
	private static Connection conn=null;
	public static Connection getConnection() throws TrainerException{
		if(conn==null)
		{
			try
			{
				FileInputStream myFile=new FileInputStream("resources/jdbc.properties");
				Properties props=new Properties();
				props.load(myFile);
				String driver=props.getProperty("driver");
				String dburl=props.getProperty("dbURL");
				String uname=props.getProperty("username");
				String pwd=props.getProperty("password");
				Class.forName(driver);
				conn=DriverManager.getConnection(dburl,uname,pwd);
				conn.commit();
			}
			catch(FileNotFoundException fe)
			{
				throw new TrainerException("Unable to find properties file"+fe.getMessage());
			}
			catch(ClassNotFoundException ce)
			{
				throw new TrainerException("Driver class not found"+ce.getMessage());
			}
			catch(IOException ie)
			{
				throw new TrainerException("problem occured while reading properties file"+ie.getMessage());
			}
			catch(SQLException se)
			{
				throw new TrainerException("problem occured when connecting to database"+se.getMessage());
			}
		}
		return conn;
	}

}
