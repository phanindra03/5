package com.asset.dao;

public interface IQueryMapper {
	static  String INSERT="insert into assetname values(?,?,?,sysdate,?,?)";
	static String SELECT="select * from assetname";
	static String SELECT_BY_ID="select * from assetname where assetId=?";

}