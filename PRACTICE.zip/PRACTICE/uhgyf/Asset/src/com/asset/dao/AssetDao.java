package com.asset.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.asset.dbutil.DbUtil;
import com.asset.dtobean.AssetDtoBean;
import com.asset.exception.AssetException;

public class AssetDao implements IAssetDao{
	
	Connection conn=null;
	int status=0;
	
	Logger log = Logger.getRootLogger();
	
	public int assetDaoInsertion(AssetDtoBean o)throws AssetException {
		PropertyConfigurator.configure("resources/log4j.properties");
		conn=DbUtil.getConnect();
		try {
		PreparedStatement pst=conn.prepareStatement(IQueryMapper.INSERT);
		pst.setString(1,o.getEmpId());
		pst.setString(2,o.getEmpName());
		pst.setString(3,o.getMobileNum());
		
		pst.setInt(4,o.getAssetId());
		pst.setInt(5,o.getQuantity());
		status=pst.executeUpdate();
		log.info("DAO LAYER -- DATA STORED SUCCESSFULLY");
		}catch(SQLException e) {
			log.warn("DAO LAYER -- DATA NOT STORED");	
		throw new AssetException("problem in storing data");
		}
		
		return status;
	}
	
	
	public List<AssetDtoBean> assetDaoRetrive()throws AssetException  {
		conn=DbUtil.getConnect();
		List<AssetDtoBean> Assetlist=null;
		
		try {
		Statement st=conn.createStatement();
		ResultSet rs= st.executeQuery(IQueryMapper.SELECT);
		Assetlist=new ArrayList<AssetDtoBean>();
		AssetDtoBean assetobj=null;
		while(rs.next()) {
			assetobj=new AssetDtoBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(5), rs.getInt(6));
			Assetlist.add(assetobj);
			
		}
		log.info("DAO LAYER -- DATA STORED SUCCESSFULLY");
		}catch(SQLException e) {
			log.warn("DAO LAYER -- DATA NOT RETRIVED");
			throw new AssetException("problem in retriving data");
		}
		return Assetlist;
	}
	
	
	public List<AssetDtoBean> assetDaoRetriveById(String assetId) throws AssetException {
		conn=DbUtil.getConnect();
		List<AssetDtoBean> Assetlist=null;
		try {
		PreparedStatement pst=conn.prepareStatement(IQueryMapper.SELECT_BY_ID);
		pst.setString(1,assetId);
		ResultSet rs=pst.executeQuery();
		Assetlist=new ArrayList<AssetDtoBean>();
		AssetDtoBean assetobj=null;
		while(rs.next()) {
			assetobj=new AssetDtoBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),rs.getInt(5), rs.getInt(6));
			Assetlist.add(assetobj);
		}
		log.info("DAO LAYER -- DATA STORED SUCCESSFULLY");
		}catch(SQLException e) {
			log.warn("DAO LAYER -- DATA NOT RETRIVED");
			throw new AssetException("problem in retriving data");
		}
		return Assetlist;
		
		
	}
	

}
