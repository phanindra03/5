package com.cg.tms.dao;

public interface QueryMappers {

	String INSERT_QUERY ="insert into trainer_details values(Trainer_Id_seq.nextval,?,?,?,?,?)";
	String GET_ID = "SELECT Trainer_Id_Seq.CURRVAL FROM DUAL";

}
