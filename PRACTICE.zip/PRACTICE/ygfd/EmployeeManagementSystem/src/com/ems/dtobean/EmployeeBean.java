package com.ems.dtobean;

public class EmployeeBean {

	private int empId;
	private String empName;
	private String empEmail;
	private String empmobile;
	private int sal;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public String getEmpmobile() {
		return empmobile;
	}
	public void setEmpmobile(String empmobile) {
		this.empmobile = empmobile;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	public EmployeeBean() {
		// TODO Auto-generated constructor stub
	}
	public EmployeeBean(int empId, String empName, String empEmail,
			String empmobile, int sal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empEmail = empEmail;
		this.empmobile = empmobile;
		this.sal = sal;
	}
	
	public EmployeeBean( String empName, String empEmail,
			String empmobile, int sal) {
			
		this.empName = empName;
		this.empEmail = empEmail;
		this.empmobile = empmobile;
		this.sal = sal;
	}
	
	
	@Override
	public String toString() {
	
	return this.empId+" "+this.empName+" "+this.empEmail+" "+this.empmobile+" "+this.sal;
	}
	
	
}
