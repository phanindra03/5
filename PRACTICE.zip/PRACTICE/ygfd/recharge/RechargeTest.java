package com.ra.test;


import org.apache.log4j.Logger;

import org.junit.Test;

import com.ra.exception.RechargeException;
import com.ra.service.RechargeServiceImpl;
import com.ra.util.DbUtil;

import junit.framework.Assert;


public class RechargeTest {

	Logger log=Logger.getRootLogger();
	
	DbUtil connection=new DbUtil();
	
	@Test
	public void testConnection1() {
		
	
		Assert.assertNotNull(connection.getDbConnection());

}
	
	@Test
	public void testConnection2() {
		
		Assert.assertEquals("the connection is not established", null, connection.getDbConnection());
		
		
	}
	

	@Test
	public void testRecharge() throws RechargeException {
		
		RechargeServiceImpl testServ=new RechargeServiceImpl();
		
		Assert.assertNotNull(testServ.rechargeServiceImpl());
				
		
	}
	
	
	
	
	
	
	
	
	
	
}
