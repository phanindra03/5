package com.cg.tms.Exceptions;

public class TrainerException extends Exception{
	public TrainerException(String msg)
	{
		super(msg);
	}

}
