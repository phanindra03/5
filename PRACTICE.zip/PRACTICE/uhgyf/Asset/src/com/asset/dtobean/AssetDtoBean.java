package com.asset.dtobean;

public class AssetDtoBean {
	private String empId;
	private String empName;
	private String mobileNum;
	private String allocateDate;
	private int assetId=(int)(Math.random()*10000);
	private int quantity=1;
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getMobileNum() {
		return mobileNum;
	}
	public void setMobileNum(String mobileNum) {
		this.mobileNum = mobileNum;
	}
	public String getAllocateDate() {
		return allocateDate;
	}
	public void setAllocateDate(String allocateDate) {
		this.allocateDate =allocateDate ;
	}
	public int getAssetId() {
		return assetId;
	}
	public void setAssetId(int assetId) {
		this.assetId =assetId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public AssetDtoBean() {
		super();
		
	}
	
	
	public AssetDtoBean(String empId, String empName, String mobileNum, String allocateDate, int assetId,
			int quantity) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.mobileNum = mobileNum;
		this.allocateDate = allocateDate;
		this.assetId = assetId;
		this.quantity = quantity;
	}
	public AssetDtoBean(String empId, String empName,String mobileNum) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.mobileNum = mobileNum;
		
	}
	@Override
	public String toString() {
		return "AssetDtoBean [empId=" + empId + ", empName=" + empName + ", mobileNum=" + mobileNum + ", allocateDate="
				+ allocateDate + ", assetId=" + assetId + ", quantity=" + quantity + "]";
	}
	

}
