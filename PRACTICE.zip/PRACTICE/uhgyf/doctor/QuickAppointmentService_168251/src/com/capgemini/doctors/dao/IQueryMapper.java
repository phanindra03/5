package com.capgemini.doctors.dao;

public interface IQueryMapper {
	static String INSERT_QUERY = "insert into doctor_appointment values(seq_appointment_id.nextval,'?','?',sysdate.'?',?,'?','?','?','?')";
	static String SEARCH_DOCTOR = "select doctor_name from problems where problem_name='?'";
	static String GET_APPOINTMENT_DETAILS = "select * from  doctor_appointment where appointment_id=?;";
	static String GET_PROBLEM_NAMES ="select problem_name from problems";
}
