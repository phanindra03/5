package com.asset.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class DbUtil {
	
	 static Logger l = Logger.getRootLogger();
	
	public static Connection conn=null;
	
	public static Connection getConnect() {
		PropertyConfigurator.configure("resources/log4j.properties");
		String url="jdbc:oracle:thin:@10.219.34.3:1521/orcl";
		String user="trg216";
		String pass="training216";
		try {
		conn=DriverManager.getConnection(url, user, pass);
		l.info("DATABASE CONNECTED");
		}catch(SQLException e) {
			l.warn("DATABASE NOT CONNECTED");
			System.out.println("not connected");
		}
		
		
		return conn;
	}
	

}
