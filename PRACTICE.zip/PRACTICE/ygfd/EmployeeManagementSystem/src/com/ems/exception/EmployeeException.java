package com.ems.exception;
//checked exception
public class EmployeeException extends Exception
{
	
	public EmployeeException() {
	
	}
	public EmployeeException(String msg) {
		super(msg);
	}

}
