package com.capgemini.doctors.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.doctors.util.DBConnecton;
import com.capgemini.doctors.bean.DoctorAppointment;
//import com.capgemini.doctors.bean.ProblemsBean;
import com.capgemini.doctors.exception.DoctorsException;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment)
			throws DoctorsException {
		Connection conn;

		Statement insertStmt = null;

		try {

			conn = DBConnecton.getConnection();
			String s = "insert into doctor_appointment values(seq_appointment_id.nextval,'"
					+ doctorAppointment.getPatientName()
					+ "','"
					+ doctorAppointment.getPhoneNumber()
					+ "',sysdate,'"
					+ doctorAppointment.getEmail()
					+ "',"
					+ doctorAppointment.getAge()
					+ ",'"
					+ doctorAppointment.getGender()
					+ "','"
					+ doctorAppointment.getProblemName()
					+ "','"
					+ doctorAppointment.getDoctorName()
					+ "','"
					+ doctorAppointment.getAppointmentStatus() + "')";
			System.out.println(s);

			insertStmt = conn.createStatement();

			int result = insertStmt.executeUpdate(s);

			if (result != 1) {
				// logger.debug("values not inserted");
				throw new DoctorsException("Sorry! insert not performed");
			} else {
				conn.commit();
			}

		} catch (SQLException | NullPointerException | DoctorsException e) {
			throw new DoctorsException(e.getMessage());
		}finally {
			try {
				insertStmt.close();
				// con.close();
			} catch (SQLException e) {
				//logger.error(e.getMessage());
				throw new DoctorsException("Error in closing db connection");

			}
		}

		return 1;
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId) throws DoctorsException {
		Connection con = DBConnecton.getConnection();
		int count = 0;

		Statement st=null;
		ResultSet resultset = null;
		DoctorAppointment da = new DoctorAppointment();

		//List<DoctorAppointment> docAppDet = new ArrayList<DoctorAppointment>();
		try {
			st=con.createStatement();
			String s="select * from  doctor_appointment where appointment_id="+appointmentId;
			resultset = st.executeQuery(s);
			while (resultset.next()) {				
				da.setPatientName(resultset.getString(2));
				da.setAppointmentStatus(resultset.getString(10));
				da.setDoctorName(resultset.getString(9));
				da.setDateOfAppointment(resultset.getDate(4));
				count++;
			}
		

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			throw new DoctorsException("Tehnical problem occured. Refer log");
		}

		if (count == 0) {
			return null;
		} else {
			return  da;
		}
	}

	@Override
	public List<String> getProblemNames() throws DoctorsException {

		Connection con = DBConnecton.getConnection();
		int count = 0;

		Statement st = null;
		ResultSet resultset = null;

		List<String> problemsList = new ArrayList<String>();
		try {
			st = con.createStatement();
			String s = "select problem_name from problems";
			resultset = st.executeQuery(s);
			while (resultset.next()) {
				problemsList.add(resultset.getString(1));
				count++;
			}

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			throw new DoctorsException("Tehnical problem occured. Refer log");
		}

		finally {
			try {
				resultset.close();
				st.close();
				// con.close();
			} catch (SQLException e) {
				// logger.error(e.getMessage());
				throw new DoctorsException("Error in closing db connection");

			}
		}

		if (count == 0)
			return null;
		else
			return problemsList;
	}

	@Override
	public String getDoctorName(String probName) throws DoctorsException {
		Connection con = DBConnecton.getConnection();
		ResultSet resultset = null;
		Statement st = null;

		String docName = null;
		try {
			st = con.createStatement();
			String s = "select doctor_name from problems where problem_name='"
					+ probName + "'";
			resultset = st.executeQuery(s);
			while (resultset.next()) {
				// prb.setDoctorName(resultset.getString(1));
				docName = (resultset.getString(1));
			}

		} catch (SQLException sqlException) {
			// logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new DoctorsException("Tehnical problem occured. Refer log");
		}finally {
			try {
				resultset.close();
				st.close();
				// con.close();
			} catch (SQLException e) {
				// logger.error(e.getMessage());
				throw new DoctorsException("Error in closing db connection");

			}
		}

		return docName;
	}

}
