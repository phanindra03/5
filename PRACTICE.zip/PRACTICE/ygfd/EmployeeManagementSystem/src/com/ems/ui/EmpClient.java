package com.ems.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ems.dtobean.EmployeeBean;
import com.ems.exception.EmployeeException;
import com.ems.service.EmployeeService;
import com.ems.service.IEmployeeService;

public class EmpClient {
	static Scanner scan=null;
	static IEmployeeService empServ=null;
	
	public static void main(String[] args) {
		System.out.println("===employee management system===");
		System.out.println("--------------------------------");
		System.out.println("1. add employee info");
		System.out.println("2. retrieveAll");
		System.out.println("3. exit");
		System.out.println("--------------------------------");
		
		scan=new Scanner(System.in);
		int option=scan.nextInt();
		switch(option){
		
		case 1:
			//get user info
			System.out.println("enter ur name");
			String name=scan.next();
			System.out.println("enter ur mobile");
			String mobile=scan.next();
			System.out.println("enter ur sal");
			int salary=scan.nextInt();
			System.out.println("enter ur mail");
			String email=scan.next();
			
			
			//set it to bean obj
			EmployeeBean emp=new EmployeeBean(name, email, mobile, salary);
			//	validation
			//if validation succesfull
			int res=0;
			try {
				res = addEmployeeInfo(emp);
			} catch (EmployeeException e) {
			
			System.out.println(e.getMessage());
			}
			
			if(res>0){
				System.out.println(res+" data is inserted");
			}
			else
			{
				System.out.println("data is not stored");
			}
			break;
			
			
		case 2:
			List<EmployeeBean> finList=null;
			try {
				finList = retrieveAllEmployeeInfo();
			} catch (EmployeeException e) {
				
				System.out.println(e.getMessage());
			}
		/*	Iterator it=finList.iterator();
			while(it.hasNext()){
				System.out.println(it.next());
			}*/
			
			for(EmployeeBean empl:finList)
			{
			System.out.println(empl);	
			}
			break;
			
		case 3:
			System.exit(0);
			
			break;
			
			default:
				
		
		
		
		}
		
	}
	
	public static int addEmployeeInfo(EmployeeBean emp) throws EmployeeException{
		//delegate the call to method in service - also pass the data
		empServ=new EmployeeService();
		int result=empServ.storeEmployee(emp);
		return result;
	}
	public static List<EmployeeBean> retrieveAllEmployeeInfo() throws EmployeeException{
		empServ=new EmployeeService();
		
		return empServ.getAllEmployees();
	}
}
