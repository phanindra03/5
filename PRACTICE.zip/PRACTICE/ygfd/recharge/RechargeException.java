package com.ra.exception;

public class RechargeException extends Exception {

	public  RechargeException() {
		
	}
	
	public RechargeException(String msg)
	{
		super(msg);
	}
	
}
