package com.cg.tms.dao;

import com.cg.tms.Exceptions.TrainerException;
import com.cg.tms.bean.TrainerDetailsdto;

public interface TrainerDao {
	public TrainerDetailsdto adddetails(TrainerDetailsdto dto);
}
