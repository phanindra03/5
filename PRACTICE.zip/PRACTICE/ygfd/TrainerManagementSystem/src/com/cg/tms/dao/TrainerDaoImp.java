package com.cg.tms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;
import com.cg.tms.Exceptions.TrainerException;
import com.cg.tms.bean.TrainerDetailsdto;
import com.cg.tms.util.DBConnection;

public class TrainerDaoImp {
	private Logger logger=Logger.getRootLogger();
			//Logger(TrainerDaoImp.class);
	public TrainerDetailsdto adddetails(TrainerDetailsdto dto) throws TrainerException
	{
		logger.info("Trainer Maintenance System Start ");
		// System.out.println("Trainer Maintenance System Start ");
			PreparedStatement insertStmt;
			
				try {
					Connection conn=DBConnection.getConnection();
					
					System.out.println("connected");
					insertStmt=conn.prepareStatement(QueryMappers.INSERT_QUERY);
					insertStmt.setString(1, dto.getTname());
					insertStmt.setString(2, dto.getLocation());
					insertStmt.setString(3,dto.getDesignation());
					insertStmt.setString(4,dto.getTechnology());
					insertStmt.setString(5,dto.getPhn());
					 int result=insertStmt.executeUpdate();
					if(result!=1)
					{
						System.out.println("values not inserted");
						throw new TrainerException("cannot process further");
					}
					else
					{
						conn.commit();
					}
				} 
				catch (SQLException e)
				{
					
					System.out.println(e);
				}
				return dto;
	}
	
	public int getTrainerId() throws TrainerException {
		TrainerDetailsdto dto=new TrainerDetailsdto();
		PreparedStatement insertStmt;
		ResultSet result=null;
		int tid=0;
		try {
			Connection conn=DBConnection.getConnection();	
			insertStmt=conn.prepareStatement(QueryMappers.GET_ID);
			  result=insertStmt.executeQuery();
			 if (result.next()) {
					tid = result.getInt(1);
				}
		} 
		catch (SQLException e)
		{		
			System.out.println(e);
		}
		return tid;
	}
	
	}

	

