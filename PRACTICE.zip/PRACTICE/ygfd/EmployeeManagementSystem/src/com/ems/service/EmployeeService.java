package com.ems.service;

import java.util.List;

import com.ems.dao.EmployeeDaoImpl;
import com.ems.dao.IEmployeeDao;
import com.ems.dtobean.EmployeeBean;
import com.ems.exception.EmployeeException;



public class EmployeeService implements IEmployeeService
{
	IEmployeeDao edao=null;
	
	@Override
	public int storeEmployee(EmployeeBean employee) throws EmployeeException {
		edao=new EmployeeDaoImpl();
		int retId=edao.storeEmployee(employee);
		return retId;
	}

	@Override
	public List<EmployeeBean> getAllEmployees() throws EmployeeException {
		edao=new EmployeeDaoImpl();
		
		return edao.getAllEmployees();
	}

}
