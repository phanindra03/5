package com.ra.service;

import java.util.List;

import com.ra.dtobean.RechargeBean;
import com.ra.exception.RechargeException;

public interface IRechargeService {

	

	int rechargeServ(RechargeBean rec) throws RechargeException;

	List<RechargeBean> rechargeServiceImpl() throws RechargeException;
	
    boolean validateName();

	boolean validateName(String name);
	
	
	
	
	
	
	
}
