package com.cg.tms.ui;

import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.tms.Exceptions.TrainerException;
import com.cg.tms.bean.TrainerDetailsdto;
import com.cg.tms.service.TrainerServiceImp;

public class UserInterface {
	private static Scanner sc;
	 static TrainerServiceImp ser=new TrainerServiceImp();
	static String tname;
	static String location;
	static String designation;
	static String technology;
	static String phn;
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		sc=new Scanner(System.in);
		initial();

	}
	static void initial() {
		int choice=0;
		while(true)
		{
		System.out.println("Welcome to Trainer Maintenance System");
		System.out.println("1.Add Trainer");
		System.out.println("2. Exit");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			addTrainer();
			break;
		case 2:
			System.out.println("Thank You!!!");
			System.exit(0);
			break;
		default :
			System.out.println("Please select the correct Choice  ");
			break;
		}
		}
		
	}
	 static void addTrainer() {
		 TrainerDetailsdto dto=new TrainerDetailsdto();
		
		 while(true)
		 {
			 System.out.println("Enter Trainer Name:");
			 tname=sc.next();
			 if((ser.isValidateTname(tname))==true)
			 {
				dto.setTname(tname);
				 break;
			 }
			 else
			 {
				 System.out.println("Enter Valid Trainer Name");
			 }
			 
		 }
		 while(true)
		 {
		System.out.println("Select Trainer Location from given Values");
		System.out.println("1.Hyderabad");
		System.out.println("2.Chennai");
		System.out.println("3.Pune");
		System.out.println("4.Bangalore");
		System.out.println("5.Mumbai");
		int loc=sc.nextInt();
		switch(loc)
		{
			case 1:
				location="Hyderabad";				
				break;
			case 2:
				location="Chennai";				
				break;
			case 3:
				location="Pune";				
				break;
			case 4:
				location="Bangalore";			
				break;
			case 5:
				location="Mumbai";
				break;
			default:
				System.out.println("Enter Valid Location");
				break;
		}
		System.out.println(location);
		dto.setLocation(location);
		break;
		 }
		 while(true)
		 {
			 System.out.println("Select Trainer Designation");
			 System.out.println("1.Consultant");
			 System.out.println("2.senior Consultant");
			 int des=sc.nextInt();
			 switch(des)
			 {
			 	case 1:
			 			designation="consultant";
			 				break;
			 	case 2:
			 			designation="senior consultant";	
			 				break;
			 	default:
			 			System.out.println("Enter valid designation");
			 				break;
			 }
			 System.out.println(designation);
			 dto.setDesignation(designation);
			 break;
		 }
		 while(true)
		 {
		 System.out.println("Select Technology");
		 System.out.println("1.jee");
		 System.out.println("2.cloud");
		 System.out.println("3.mainframes");
		int tech=sc.nextInt();
		switch(tech)
		{
		case 1:
			technology="jee"; 
			break;
		case 2:
			technology="cloud";
			break;
		case 3:
			technology="mainframes";
			break;
		default:
			System.out.println("Enter Valid Technology");
			break;
		}
		System.out.println(technology);
		dto.setTechnology(technology);
		break;
		 }
		 while(true)
		 {
		System.out.println("Enter Contact Number");
		 phn=sc.nextLine();
		if((ser.isValidPhn(phn))==true)
		{
		break;
		}
		else
		{
			System.out.println("Enter Phone Number with 10 digits");
		}
		}
		 System.out.println(phn);
		 dto.setPhn(phn);
		 try {
			ser.adddetails(dto);
			System.out.println("Inserted Successfully!!!!");
			int Trainer_Id=ser.getTrainerId();
			System.out.println("The Trainer Id is:"+Trainer_Id);
		} catch (TrainerException e) {
			e.printStackTrace();
		}
	}
	 

}
