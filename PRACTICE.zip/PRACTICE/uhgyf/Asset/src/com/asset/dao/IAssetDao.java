package com.asset.dao;

import java.util.List;

import com.asset.dtobean.AssetDtoBean;
import com.asset.exception.AssetException;

public interface IAssetDao {
	public abstract int assetDaoInsertion(AssetDtoBean object)throws AssetException;
	public abstract List<AssetDtoBean> assetDaoRetrive()throws AssetException;
	public abstract List<AssetDtoBean> assetDaoRetriveById(String assetId) throws AssetException;
}
