package com.asset.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.asset.dao.AssetDao;
import com.asset.dao.IAssetDao;
import com.asset.dtobean.AssetDtoBean;
import com.asset.exception.AssetException;

public class AssetService implements IAssetService{
	static IAssetDao assetDao=null;
	
	public  int assetServiceInsertion(AssetDtoBean object) throws AssetException{
		assetDao=new AssetDao();
		int status=assetDao.assetDaoInsertion(object);
		return status;
	}
	public  List<AssetDtoBean> assetServiceRetrive() throws AssetException{
		assetDao=new AssetDao();
		return assetDao.assetDaoRetrive();
	}
	public  List<AssetDtoBean> assetServiceRetriveById(String assetId) throws AssetException{
		assetDao=new AssetDao();
		return assetDao.assetDaoRetriveById(assetId);
	}
	
	public static boolean validateempId(String empId) {
	    Pattern p=Pattern.compile("[E][M][P][0-9]{3}");
		Matcher m=p.matcher(empId);
		if(m.matches()==true) {
			return true;
		}else {
			System.out.println("ID SHOULD BE LIKE EMP*** ");
			System.out.println("ENTER EMPID AGAIN");
			return false;
		}
	}
	public static int validateempName(String empName) {
	    Pattern p=Pattern.compile("[A-Z][A-Za-z]{3,15}");
		Matcher m=p.matcher(empName);
		if(m.matches()==true) {
			return 1;
		}else {
			System.out.println("NAME SHOULD START WITH UPPER CASE AND LENGTH SHOULD NOT EXCEED 15 CHARACTER");
			System.out.println("ENTER NAME AGAIN");
			return 0;
		}
	}
	public static int validatemobileNumber(String mobileNumber) {
	    Pattern p=Pattern.compile("[6-9][0-9]{9}");
		Matcher m=p.matcher(mobileNumber);
		if(m.matches()==true) {
			return 1;
		}else {
			System.out.println("MOBILE NUMBER SHOULD START WITH 6,7,8,9 AND MUST BE 10 DIGIT");
			System.out.println("ENTER MOBILE NUMBER AGAIN");
			return 0;
		}
	}
	/*public static int validateallocateDate(String allocateDate) {
	    Pattern p=Pattern.compile("[0-2][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]");
		Matcher m=p.matcher(allocateDate);
		if(m.matches()==true) {
			return 1;
		}else {
			System.out.println("format to follow YYYY-MM-DD");
			System.out.println("ENTER DATE AGAIN");
			return 0;
		}
	}*/
}
