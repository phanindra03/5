package com.ems.dao;

import java.util.List;

import com.ems.dtobean.EmployeeBean;
import com.ems.exception.EmployeeException;

public interface IEmployeeDao {
	public abstract int storeEmployee(EmployeeBean employee)throws EmployeeException;
	
	public abstract List<EmployeeBean> getAllEmployees() throws EmployeeException;
}
